	<div class="card mt-5">
				<div class="card-body">
					<a href="index.php" class="btn btn-primary">Beranda</a>
					<a href="data_barang.php" class="btn btn-primary">Data Barang</a>
					<a href="pembelian.php" class="btn btn-primary">Pembelian</a>
					<a href="data_pengguna.php" class="btn btn-primary">Data Pengguna</a>
					<a href="../logout.php" class="btn btn-danger">Keluar</a>
				</div>
			</div>